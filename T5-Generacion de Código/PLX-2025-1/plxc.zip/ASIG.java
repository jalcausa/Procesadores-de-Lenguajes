public class ASIG extends EXPRESION {

    public ASIG(String id, EXPRESION dcha) {
        super(null, dcha);
        this.temp = id;
    }

    public void gc() {
        this.dcha.gc();
        Generador.asigna(this.getTemp(), ((EXPRESION)this.dcha).getTemp());
    }
}
