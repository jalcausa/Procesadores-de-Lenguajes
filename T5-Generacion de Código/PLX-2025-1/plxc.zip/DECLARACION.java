public class DECLARACION extends AST {

    private String identificador;

    public DECLARACION(String id) {
        super(null, null);
        this.identificador = id;
    }

    public void gc() {
    }
}
